package com.techelevator.dao;

import com.techelevator.exception.DaoException;
import com.techelevator.model.User;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

public class JdbcUserDaoTests extends BaseDaoTests {
    protected static final User USER_1 = new User(1, "user1", "user1", "555 Main Street", "Cleveland", "OH", "44115", "ROLE_USER");
    protected static final User USER_2 = new User(2,"user2", "user2", "123 Elm Street", "New York", "NY", "10001", "ROLE_USER");
    private static final User USER_3 = new User(3,"user3", "user3", "101 33rd Avenue", "Ann Arbor", "MI", "48103","ROLE_USER");

    private JdbcUserDao dao;

    @Before
    public void setup() {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        dao = new JdbcUserDao(jdbcTemplate);
    }

    @Test
    public void getUserByUsername_given_null_returns_null_user() {
        User user = dao.getUserByUsername(null);
        Assert.assertNull("getUserByUsername with null username did not return null user", user);
    }

    @Test
    public void getUserByUsername_given_invalid_username_returns_null_user() {
        User user = dao.getUserByUsername("invalid");
        Assert.assertNull("getUserByUsername with invalid username did not return null user", user);
    }

    @Test
    public void getUserByUsername_given_valid_user_returns_correct_user() {
        User actualUser = dao.getUserByUsername(USER_1.getUsername());
        Assert.assertEquals("getUserByUsername with valid username did not return correct user",
                USER_1, actualUser);
    }

    @Test
    public void getUserById_given_invalid_user_id_returns_null() {
        User user = dao.getUserById(-1);
        Assert.assertNull("getUserById with invalid userId did not return null user", user);
    }

    @Test
    public void getUserById_given_valid_user_id_returns_user() {
        User actualUser = dao.getUserById(USER_1.getId());
        Assert.assertEquals("getUserById with valid id did not return correct user", USER_1, actualUser);
    }

    @Test
    public void findAll_returns_all_users() {
        List<User> users = dao.getUsers();

        Assert.assertNotNull("getUsers returned a null list of users", users);
        Assert.assertEquals("getUsers returned a list with the incorrect number of users", 3, users.size());
        Assert.assertEquals("getUsers returned a list in incorrect order", USER_1, users.get(0));
        Assert.assertEquals("getUsers returned a list in incorrect order", USER_2, users.get(1));
        Assert.assertEquals("getUsers returned a list in incorrect order", USER_3, users.get(2));
    }

    @Test(expected = DaoException.class)
    public void create_user_with_null_username() {
        dao.createUser(new User(null, USER_3.getHashedPassword(), "101 33rd Avenue", "Ann Arbor", "MI", "48103","ROLE_USER"));
    }

    @Test(expected = DaoException.class)
    public void create_user_with_existing_username() {
        dao.createUser(new User(USER_1.getUsername(), USER_3.getHashedPassword(), "555 Main Street", "Cleveland", "OH", "44115", "ROLE_USER"));
    }

    @Test(expected = DaoException.class)
    public void create_user_with_null_password() {
        dao.createUser(new User(USER_3.getUsername(), null, "101 33rd Avenue", "Ann Arbor", "MI", "48103","ROLE_USER"));
    }

    @Test
    public void create_user_creates_a_user() {

        User newUser = new User("new-user", "user", "555 Main Street", "Cleveland", "OH", "44115", "ROLE_USER");

        User user = dao.createUser(newUser);
        Assert.assertNotNull("Call to create should return non-null user", user);

        User actualUser = dao.getUserById(user.getId());
        Assert.assertNotNull("Call to getUserById after call to create should return non-null user", actualUser);

        newUser.setId(actualUser.getId());
        actualUser.setHashedPassword(newUser.getHashedPassword()); // reset password back to unhashed password for testing
        Assert.assertEquals(newUser, actualUser);
    }
}


package com.techelevator.model;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;

/**
 * RegisterUserDto is a class used to hold the registration information for a new user
 * that's sent from the client to the server for the register endpoint.
 *
 * The acronym DTO is being used for "data transfer object". It means that this type of
 * class is specifically created to transfer data between the client and the server.
 */
public class RegisterUserDto {

    @NotEmpty
    private String username;
    @NotEmpty
    private String password;
    @NotEmpty
    private String confirmPassword;
    private String address;
    private String city;
    @NotEmpty
    @Pattern(regexp = "^(AL|AK|AR|AZ|CA|CO|CT|DC|DE|FL|GA|HI|IA|ID|IL|IN|KS|KY|LA|MA|MD|ME|MI|MN|MO|MS|MT|NC|ND|NE|NH|NJ|NM|NV|NY|OH|OK|OR|PA|RI|SC|SD|TN|TX|UT|VA|VT|WA|WI|WV|WY)$",
            message = "State code is invalid")
    private String stateCode;
    @NotEmpty
    @Pattern(regexp = "^[0-9][0-9][0-9][0-9][0-9]$",
            message = "ZIP must be 5 digits")
    private String ZIP;
    @NotEmpty(message = "Please select a role for this user.")
    private String role;

    public RegisterUserDto(String username, String password, String confirmPassword, String address, String city, String stateCode, String ZIP, String role) {
        this.username = username;
        this.password = password;
        this.confirmPassword = confirmPassword;
        this.address = address;
        this.city = city;
        this.stateCode = stateCode;
        this.ZIP = ZIP;
        this.role = role;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public String getZIP() {
        return ZIP;
    }

    public void setZIP(String ZIP) {
        this.ZIP = ZIP;
    }

    public String getRole() {
        return role;
    }

    public boolean isPasswordsMatch(){
        return password.equals(confirmPassword);
    }
}
